from pathlib import Path

from langchain_chroma import Chroma

from .embeddings import get_embeddings
from .ingestion import load_and_chunk


def get_store(settings):
    return Chroma(collection_name=settings.chroma_collection, persist_directory=str(settings.chroma_directory), embedding_function=get_embeddings(settings.embedding_model))


def ensure_index(settings):
    settings.chroma_directory.mkdir(parents=True, exist_ok=True)
    store = get_store(settings)
    if store._collection.count() == 0:
        chunks = load_and_chunk(settings.pdf_path, settings.chunk_size, settings.chunk_overlap)
        store.add_documents(chunks, ids=[chunk.metadata["chunk_id"] for chunk in chunks])
    return store
