ROUTER_PROMPT = '''Classify the user question into exactly one route: direct, thematic, or analytical.
 direct = one specific fact, metric, date, or narrowly scoped statement.
 thematic = broad explanation, strategy, risks, drivers, or a topic spanning passages.
 analytical = comparison, change analysis, relationships, or synthesis across dimensions.
Return JSON only: {"route":"direct|thematic|analytical","reason":"...","confidence":0.0}.
Question: {question}'''

EXPANSION_PROMPT = '''Create up to {max_expansions} short search queries for the question below. Preserve intent, add no new facts, and return JSON only as {"queries":["..."]}.
Question: {question}'''

ANSWER_PROMPTS = {
    "direct": "Answer the question using only the supplied Tesla report context. Be concise, preserve exact figures, and cite page numbers in square brackets. If evidence is insufficient, say so. Question: {question}\nContext:\n{context}",
    "thematic": "Synthesize the supplied Tesla report context into a concise, evidence-based answer. Distinguish report facts from interpretation and cite page numbers in square brackets. Do not use outside knowledge. Question: {question}\nContext:\n{context}",
    "analytical": "Analyze the question using only the supplied Tesla report context. Explain comparisons or changes carefully, label interpretations, preserve exact figures, and cite page numbers in square brackets. If evidence is insufficient, say so. Question: {question}\nContext:\n{context}",
}
