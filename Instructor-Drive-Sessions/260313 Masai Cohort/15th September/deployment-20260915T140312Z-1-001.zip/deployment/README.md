# Simple RAG Application

This is a beginner-friendly implementation of a Retrieval-Augmented Generation (RAG) application. It is designed to be simple, easy to understand, and quick to deploy for teaching/learning purposes.

## Tech Stack
- **FastAPI**: The backend server framework. Fast to write and automatically provides API documentation.
- **ChromaDB**: The vector database used to store and retrieve text embeddings.
- **Groq API**: Used to query the `llama-3.1-70b-versatile` language model.
- **Vanilla HTML/JS**: A simple frontend without complicated tooling.

## Setup Instructions

1. **Create Virtual Environment & Install Dependencies**
   It is best practice to use a Python virtual environment. Open your terminal in this directory and run:
   
   *On Windows (PowerShell):*
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate
   pip install -r requirements.txt
   ```
   
   *On Mac/Linux:*
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Set your Groq API Key**
   You need a free API key from [Groq](https://console.groq.com/). Open the `.env` file in the project directory and replace `your-api-key-here` with your actual API key:
   ```env
   GROQ_API_KEY=your-real-groq-api-key
   ```

3. **Run the Application**
   ```bash
   python main.py
   ```

4. **Access the App**
   - **Frontend UI**: Open your browser and go to [http://localhost:8000/](http://localhost:8000/)
   - **Interactive API Docs (Swagger)**: Go to [http://localhost:8000/docs](http://localhost:8000/docs)

## How it Works
1. `main.py` is the entry point. It creates a FastAPI application.
2. At startup, it loads the data from `tsla-20231231-gen.pdf` into a localized `chroma_db` folder (if it hasn't been loaded already).
3. The `/ask` endpoint takes a question, searches the Chroma vector database for relevant context fragments, and constructs a detailed prompt.
4. Finally, it passes both the context and question to the Llama model via Groq!
