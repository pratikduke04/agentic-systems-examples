from dataclasses import dataclass
from pathlib import Path
import os

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / ".env")


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    app_title: str = os.getenv("APP_TITLE", "Tesla Financial Report RAG Assistant")
    demo_mode: bool = _bool("DEMO_MODE", False)
    pdf_path: Path = ROOT_DIR / os.getenv("PDF_PATH", "tsla-20231231-gen.pdf")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    chroma_directory: Path = ROOT_DIR / os.getenv("CHROMA_PERSIST_DIRECTORY", "chroma_db")
    chroma_collection: str = os.getenv("CHROMA_COLLECTION", "tesla_financial_report")
    chunk_size: int = int(os.getenv("CHUNK_SIZE", "1000"))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", "150"))
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_model: str = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b")
    groq_temperature: float = float(os.getenv("GROQ_TEMPERATURE", "0.1"))
    groq_max_tokens: int = int(os.getenv("GROQ_MAX_TOKENS", "1200"))
    default_top_k: int = int(os.getenv("DEFAULT_TOP_K", "5"))
    direct_top_k: int = int(os.getenv("DIRECT_TOP_K", "3"))
    final_context_chunks: int = int(os.getenv("FINAL_CONTEXT_CHUNKS", "3"))
    reranker_model: str = os.getenv("RERANKER_MODEL", "BAAI/bge-reranker-base")
    rerank_top_n: int = int(os.getenv("RERANK_TOP_N", "3"))
    enable_query_expansion: bool = _bool("ENABLE_QUERY_EXPANSION", True)
    max_query_expansions: int = min(int(os.getenv("MAX_QUERY_EXPANSIONS", "3")), 3)
    enable_semantic_cache: bool = _bool("ENABLE_SEMANTIC_CACHE", True)
    cache_threshold: float = float(os.getenv("SEMANTIC_CACHE_THRESHOLD", "0.90"))
    cache_ttl_seconds: int = int(os.getenv("SEMANTIC_CACHE_TTL_SECONDS", "3600"))
    router_confidence_threshold: float = float(os.getenv("ROUTER_CONFIDENCE_THRESHOLD", "0.60"))


settings = Settings()
