from src.models import RetrievedChunk
from src.retrieval import Retriever

class FakeStore:
    def similarity_search_with_relevance_scores(self, query, k):
        return [(type("Doc", (), {"page_content": "Tesla revenue", "metadata": {"chunk_id": "a", "source": "report.pdf", "page": 2}})(), 0.9)]

def test_retrieval_returns_metadata():
    result = Retriever(FakeStore()).search(["revenue"], 3)
    assert isinstance(result[0], RetrievedChunk)
    assert result[0].page == 2
    assert result[0].chunk_id == "a"
