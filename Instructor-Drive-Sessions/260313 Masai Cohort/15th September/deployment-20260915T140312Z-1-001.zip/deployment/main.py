import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from dotenv import load_dotenv
from contextlib import asynccontextmanager

# LangChain imports to match the Jupyter Notebook RAG workflow
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings.sentence_transformer import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma
from groq import Groq

# Load environment variables
load_dotenv()

# We will initialize the vector db in startup event
# We're switching to LangChain's Chroma wrapper 
db = None

# We'll use the smaller huggingface model for faster processing
embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

@asynccontextmanager
async def lifespan(app: FastAPI):
    global db
    print("Initializing LangChain RAG Vector Database...")
    db = Chroma(persist_directory="./chroma_db", embedding_function=embedding_function)
    
    # Load PDF data only if ChromaDB has no existing documents
    if len(db.get()["ids"]) == 0:
        pdf_path = "tsla-20231231-gen.pdf"
        try:
            print(f"Loading '{pdf_path}' using PyPDFLoader...")
            loader = PyPDFLoader(pdf_path)
            
            # Replicating the notebook's text splitter logic
            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name='cl100k_base',
                chunk_size=512,
                chunk_overlap=16
            )
            
            print("Splitting document into chunks...")
            docs = loader.load_and_split(text_splitter)
            
            if docs:
                print(f"Adding {len(docs)} chunks to Chroma DB. This may take a moment...")
                db.add_documents(docs)
                print(f"Successfully loaded {len(docs)} chunks from {pdf_path} into ChromaDB!")
        except Exception as e:
            print(f"Could not load PDF data from {pdf_path}:", e)
    else:
        print(f"ChromaDB already contains {len(db.get()['ids'])} documents. Skipping PDF generation.")

    yield
    print("Shutting down Simple RAG API.")

# Setup FastAPI with the lifespan context manager (fixes the deprecation warning you saw)
app = FastAPI(
    title="Simple RAG App API",
    description="A beginner-friendly RAG application backend using FastAPI, LangChain, and Groq.",
    lifespan=lifespan
)

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "your-groq-api-key-here")
groq_client = Groq(api_key=GROQ_API_KEY)

class DocumentRequest(BaseModel):
    text: str

class QueryRequest(BaseModel):
    question: str

@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    try:
        with open("index.html", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "<h1>Welcome to Simple RAG API! (index.html not found)</h1><p>Go to <a href='/docs'>/docs</a> API documentation.</p>"

@app.post("/add_document")
async def api_add_document(request: DocumentRequest):
    if db is None:
        raise HTTPException(status_code=500, detail="Database not initialized yet.")
    db.add_texts([request.text])
    return {"message": "Document successfully added to the knowledge base!"}

@app.post("/ask")
async def api_ask_question(request: QueryRequest):
    if db is None:
        raise HTTPException(status_code=500, detail="Database not initialized yet.")
    
    # Step A: Retrieve relevant context from LangChain Chroma DB
    docs = db.similarity_search(request.question, k=3) # Get the top 3 most relevant chunks
    
    if not docs:
         return {"answer": "I don't have enough context in my database to answer that.", "context": []}
         
    # Combine retrieved documents into a single text block
    retrieved_texts = [doc.page_content for doc in docs]
    context_text = "\n\n---\n\n".join(retrieved_texts)
    
    # Step B: Construct the prompt connecting context with the user's question
    system_prompt = f"""You are a helpful assistant. Please answer the user's question based ONLY on the provided context below.
    If the context does not contain the answer, say "I cannot answer this based on the provided context."
    
    Context:
    {context_text}
    """
    
    # Step C: Ask the LLM via Groq API
    try:
        chat_completion = groq_client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": request.question}
            ],
            model="llama-3.3-70b-versatile",
            temperature=0.3,
        )
        
        answer = chat_completion.choices[0].message.content
        return {
            "answer": answer,
            "context": retrieved_texts
        }
    except Exception as e:
        if "AuthenticationError" in str(type(e)):
            raise HTTPException(status_code=401, detail="Invalid Groq API Key.")
        raise HTTPException(status_code=500, detail=f"Error communicating with Groq: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    # To run this script: python main.py
    uvicorn.run(app, host="0.0.0.0", port=8000)
