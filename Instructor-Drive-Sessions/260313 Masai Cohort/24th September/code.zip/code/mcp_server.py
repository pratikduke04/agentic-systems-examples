"""Minimal MCP server exposing the Tesla RAG pipeline as a tool."""
from fastmcp import FastMCP

from src.config import settings
from src.embeddings import get_embeddings
from src.generation import get_llm
from src.orchestrator import PipelineOrchestrator
from src.retrieval import Reranker
from src.vectorstore import ensure_index

mcp = FastMCP("Tesla Financial Report RAG")

_orchestrator = None


def _get_orchestrator() -> PipelineOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        store = ensure_index(settings)
        embeddings = get_embeddings(settings.embedding_model)
        llm = get_llm(settings)
        reranker = Reranker(settings.reranker_model) if llm else None
        _orchestrator = PipelineOrchestrator(settings, store, embeddings, llm, reranker)
    return _orchestrator


@mcp.tool
def ask_tesla_report(question: str) -> str:
    """Ask a question about Tesla's financial report and get a grounded answer."""
    return _get_orchestrator().ask(question).answer


if __name__ == "__main__":
    mcp.run()
