from datetime import timedelta
from src.cache import SemanticCache

class FakeEmbeddings:
    def embed_query(self, text):
        return [1.0, 0.0] if "revenue" in text.lower() else [0.0, 1.0]

def test_cache_hit_and_expiry():
    cache = SemanticCache(FakeEmbeddings(), 0.9, 3600)
    cache.put("What was revenue?", "answer", {})
    assert cache.lookup("How much revenue?").hit
    cache.entries[0].expires_at -= timedelta(seconds=3601)
    assert not cache.lookup("How much revenue?").hit

def test_cache_threshold():
    cache = SemanticCache(FakeEmbeddings(), 0.99, 3600)
    cache.put("What was revenue?", "answer", {})
    assert cache.lookup("What was cash?").hit is False
