from src.router import QueryRouter

def test_routes_without_llm():
    router = QueryRouter(None)
    assert router.route("What was Tesla's revenue?").route == "direct"
    assert router.route("What are Tesla's major growth drivers?").route == "thematic"
    assert router.route("Compare Tesla's margins across the reported years and explain the change.").route == "analytical"
