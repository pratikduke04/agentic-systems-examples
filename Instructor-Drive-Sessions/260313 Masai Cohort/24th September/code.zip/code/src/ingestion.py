from pathlib import Path
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter


def load_and_chunk(pdf_path: Path, chunk_size: int, chunk_overlap: int):
    if not pdf_path.exists():
        raise FileNotFoundError(f"Tesla financial report not found: {pdf_path}")
    documents = PyPDFLoader(str(pdf_path)).load()
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = splitter.split_documents(documents)
    for index, chunk in enumerate(chunks):
        metadata = dict(chunk.metadata)
        page = metadata.get("page")
        chunk.metadata = {
            "source": Path(metadata.get("source", pdf_path.name)).name,
            "page": int(page) + 1 if isinstance(page, int) else page,
            "chunk_id": f"{Path(pdf_path).stem}-{index:05d}",
            "document_name": Path(pdf_path).name,
        }
    return chunks
