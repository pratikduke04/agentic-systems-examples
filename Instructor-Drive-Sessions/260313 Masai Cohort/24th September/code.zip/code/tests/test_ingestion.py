from pathlib import Path
from src.ingestion import load_and_chunk

def test_pdf_metadata_is_preserved():
    chunks = load_and_chunk(Path("tsla-20231231-gen.pdf"), 1000, 150)
    assert chunks
    assert chunks[0].metadata["chunk_id"]
    assert chunks[0].metadata["source"] == "tsla-20231231-gen.pdf"
    assert chunks[0].metadata["page"] >= 1
