import json
import re
from .models import RouterDecision
from .prompts import ROUTER_PROMPT


class QueryRouter:
    def __init__(self, llm, confidence_threshold: float = 0.6):
        self.llm = llm
        self.confidence_threshold = confidence_threshold

    def route(self, question: str) -> RouterDecision:
        if not self.llm:
            return self._heuristic(question)
        try:
            raw = self.llm.invoke(ROUTER_PROMPT.format(question=question))
            text = raw.content if hasattr(raw, "content") else str(raw)
            data = json.loads(re.search(r"\{.*\}", text, re.S).group(0))
            route = data.get("route") if data.get("route") in {"direct", "thematic", "analytical"} else "thematic"
            confidence = float(data.get("confidence", 0.0))
            if confidence < self.confidence_threshold:
                route = "thematic"
            return RouterDecision(route, str(data.get("reason", "LLM classification")), confidence)
        except Exception:
            return RouterDecision("thematic", "Router fallback after classification failure", 0.0)

    @staticmethod
    def _heuristic(question: str) -> RouterDecision:
        lowered = question.lower()
        analytical = ("compare" in lowered or "versus" in lowered or " across " in f" {lowered} " or "explain the change" in lowered)
        direct_words = ("what was", "how many", "what is", "when did", "how much")
        if analytical:
            return RouterDecision("analytical", "Comparison or change analysis detected", 0.9)
        if any(word in lowered for word in direct_words) and len(question.split()) < 14:
            return RouterDecision("direct", "Specific fact pattern detected", 0.9)
        return RouterDecision("thematic", "Broad explanatory question detected", 0.8)
