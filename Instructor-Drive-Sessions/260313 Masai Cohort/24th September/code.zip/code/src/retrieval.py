import json
import re
from .models import RetrievedChunk
from .prompts import EXPANSION_PROMPT


class QueryExpander:
    def __init__(self, llm, max_expansions: int):
        self.llm, self.max_expansions = llm, min(max_expansions, 3)

    def expand(self, question: str) -> list[str]:
        if not self.llm:
            return []
        try:
            raw = self.llm.invoke(EXPANSION_PROMPT.format(question=question, max_expansions=self.max_expansions))
            text = raw.content if hasattr(raw, "content") else str(raw)
            data = json.loads(re.search(r"\{.*\}", text, re.S).group(0))
            return list(dict.fromkeys(str(item).strip() for item in data.get("queries", []) if str(item).strip()))[:3]
        except Exception:
            return []


class Retriever:
    def __init__(self, store):
        self.store = store

    def search(self, queries: list[str], top_k: int) -> list[RetrievedChunk]:
        merged = {}
        for query in queries:
            for document, score in self.store.similarity_search_with_relevance_scores(query, k=top_k):
                metadata = document.metadata
                item = RetrievedChunk(metadata["chunk_id"], document.page_content, metadata.get("source", "unknown"), metadata.get("page"), float(score))
                if item.chunk_id not in merged or item.retrieval_score < score:
                    merged[item.chunk_id] = item
        return sorted(merged.values(), key=lambda item: item.retrieval_score, reverse=True)


class Reranker:
    def __init__(self, model_name: str):
        from sentence_transformers import CrossEncoder
        self.model = CrossEncoder(model_name, device="cpu")

    def rerank(self, question: str, chunks: list[RetrievedChunk], top_n: int) -> list[RetrievedChunk]:
        if not chunks:
            return []
        scores = self.model.predict([(question, chunk.text) for chunk in chunks])
        for chunk, score in zip(chunks, scores):
            chunk.rerank_score = float(score)
        return sorted(chunks, key=lambda item: item.rerank_score or 0.0, reverse=True)[:top_n]
