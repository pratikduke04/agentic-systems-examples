import requests
resp = requests.post("http://localhost:8000/ask", json={"question": "What vehicles does Tesla manufacture?"})
data = resp.json()
print("ANSWER:")
print(data.get("answer"))
print("\nCONTEXT:")
for c in data.get("context", []):
    print("---")
    print(c)
