import time
from .models import PipelineResult
from .generation import generate_answer


class PipelineOrchestrator:
    def __init__(self, settings, store, embeddings, llm=None, reranker=None):
        self.settings, self.store, self.embeddings, self.llm, self.reranker = settings, store, embeddings, llm, reranker
        from .cache import SemanticCache
        from .retrieval import QueryExpander, Retriever
        from .router import QueryRouter
        self.cache = SemanticCache(embeddings, settings.cache_threshold, settings.cache_ttl_seconds)
        self.router, self.expander, self.retriever = QueryRouter(llm, settings.router_confidence_threshold), QueryExpander(llm, settings.max_query_expansions), Retriever(store)

    def ask(self, question: str) -> PipelineResult:
        started = time.perf_counter()
        cache_result = self.cache.lookup(question) if self.settings.enable_semantic_cache else None
        if cache_result and cache_result.hit:
            return PipelineResult(cache_result.answer or "", "cached", True, cache_result.similarity, cache_result.cached_question, sources=cache_result.metadata.get("sources", []), latency_ms=(time.perf_counter() - started) * 1000, diagnostics=cache_result.metadata)
        decision = self.router.route(question)
        query_expansions = self.expander.expand(question) if decision.route in {"thematic", "analytical"} and self.settings.enable_query_expansion else []
        queries = [question] + query_expansions
        top_k = self.settings.direct_top_k if decision.route == "direct" else self.settings.default_top_k
        retrieved = self.retriever.search(queries, top_k)
        reranked = self.reranker.rerank(question, retrieved, self.settings.rerank_top_n) if self.reranker else retrieved[:self.settings.final_context_chunks]
        final_chunks = (reranked or retrieved)[:self.settings.final_context_chunks]
        answer = generate_answer(self.llm, question, decision.route, final_chunks, self.settings.demo_mode)
        sources = list(dict.fromkeys(f"{chunk.source}, page {chunk.page}" for chunk in final_chunks))
        diagnostics = {"route_reason": decision.reason, "route_confidence": decision.confidence, "query_expansion_enabled": bool(query_expansions), "initial_retrieval_count": len(retrieved), "reranking_enabled": bool(self.reranker), "final_context_count": len(final_chunks)}
        result = PipelineResult(answer, decision.route, False, cache_result.similarity if cache_result else None, cache_result.cached_question if cache_result else None, query_expansions, retrieved, final_chunks, sources, (time.perf_counter() - started) * 1000, diagnostics)
        if self.settings.enable_semantic_cache:
            self.cache.put(question, answer, {"route": decision.route, "sources": sources, **diagnostics})
        return result
