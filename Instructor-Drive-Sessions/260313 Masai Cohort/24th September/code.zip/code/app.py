import streamlit as st
from src.config import settings
from src.embeddings import get_embeddings
from src.generation import get_llm
from src.orchestrator import PipelineOrchestrator
from src.retrieval import Reranker
from src.vectorstore import ensure_index

st.set_page_config(page_title=settings.app_title, page_icon="⚡", layout="wide")

@st.cache_resource(show_spinner="Loading report index and local models...")
def build_orchestrator():
    store = ensure_index(settings)
    embeddings = get_embeddings(settings.embedding_model)
    llm = get_llm(settings)
    reranker = Reranker(settings.reranker_model) if llm else None
    return PipelineOrchestrator(settings, store, embeddings, llm, reranker)

st.markdown("""<style>
:root { --ink:#17221f; --mint:#d8f3dc; --gold:#f4b942; --paper:#f8f7f2; }
.stApp { background: linear-gradient(135deg, #f8f7f2 0%, #e8f3ed 55%, #d8f3dc 100%); color: var(--ink); }
.block-container { max-width: 1180px; padding-top: 3rem; }
.hero { padding: 2rem 0 1rem; border-bottom: 1px solid rgba(23,34,31,.18); }
.eyebrow { color:#5e7867; letter-spacing:.12em; text-transform:uppercase; font-size:.76rem; font-weight:700; }
.hero h1 { font-family: Georgia, serif; font-size:3.2rem; line-height:1.02; margin:.35rem 0; color:var(--ink); }
.hero p { font-size:1.1rem; max-width:650px; color:#496158; }
[data-testid="stMetric"] { background:rgba(255,255,255,.62); border:1px solid rgba(23,34,31,.12); padding:1rem; border-radius:8px; }
</style>""", unsafe_allow_html=True)
st.markdown('<div class="hero"><div class="eyebrow">Tesla financial report / local RAG intelligence</div><h1>Ask the report<br>better questions.</h1><p>Answers are grounded in the supplied Tesla filing, with the retrieval path visible when you need to inspect it.</p></div>', unsafe_allow_html=True)

if "result" not in st.session_state:
    st.session_state.result = None
if "recent" not in st.session_state:
    st.session_state.recent = []

examples = ["What was Tesla's total revenue?", "What are Tesla's major growth drivers?", "What risks does Tesla identify?", "Compare Tesla's financial performance across the reported years."]
question = st.text_input("Question", placeholder="Ask a question about the Tesla financial report...", value=st.session_state.get("question_value", ""))
cols = st.columns(4)
for index, example in enumerate(examples):
    if cols[index].button(example, use_container_width=True):
        st.session_state.question_value = example
        st.rerun()

if st.button("Ask the report", type="primary", use_container_width=False) and question.strip():
    try:
        with st.spinner("Tracing the evidence through the report..."):
            result = build_orchestrator().ask(question.strip())
        st.session_state.result = result
        st.session_state.recent = [question.strip()] + [item for item in st.session_state.recent if item != question.strip()]
    except FileNotFoundError:
        st.error("Tesla financial report not found. Please place the PDF in the configured data directory.")
    except RuntimeError as error:
        st.error(str(error) + " Add a key to .env or set DEMO_MODE=true for a local smoke test.")
    except Exception as error:
        st.error(f"Pipeline initialization failed: {error}")

result = st.session_state.result
if result:
    st.divider()
    st.subheader("Answer")
    st.write(result.answer)
    if result.sources:
        st.markdown("**Sources**")
        for source in result.sources:
            st.write(f"- Tesla Financial Report, {source}")
    st.subheader("RAG pipeline details")
    metrics = st.columns(5)
    metrics[0].metric("Route", result.route.title())
    metrics[1].metric("Cache", "HIT" if result.cache_hit else "MISS")
    metrics[2].metric("Expanded queries", len(result.expanded_queries))
    metrics[3].metric("Retrieved", len(result.retrieved_chunks))
    metrics[4].metric("Latency", f"{result.latency_ms:.0f} ms")
    with st.expander("Inspect retrieval metadata"):
        st.json({**result.diagnostics, "final_chunks": len(result.reranked_chunks), "cache_similarity": result.cache_similarity, "cached_question": result.cached_question})
        for chunk in result.reranked_chunks:
            st.caption(f"{chunk.source}, page {chunk.page} | retrieval {chunk.retrieval_score:.3f}")
            st.write(chunk.text[:500] + ("..." if len(chunk.text) > 500 else ""))

with st.sidebar:
    st.markdown("### Session")
    st.caption("Local Tesla Financial Report RAG Assistant")
    if settings.demo_mode:
        st.success("Demo mode enabled")
    elif not settings.groq_api_key:
        st.warning("GROQ_API_KEY is not configured")
    if st.session_state.recent:
        st.markdown("**Recent questions**")
        for item in st.session_state.recent[:5]:
            st.caption(item)
