from langchain_groq import ChatGroq
from .prompts import ANSWER_PROMPTS


def get_llm(settings):
    if not settings.groq_api_key:
        return None
    return ChatGroq(api_key=settings.groq_api_key, model=settings.groq_model, temperature=settings.groq_temperature, max_tokens=settings.groq_max_tokens)


def generate_answer(llm, question: str, route: str, chunks, demo_mode: bool = False) -> str:
    if not chunks:
        return "I could not find sufficient information in the Tesla financial report to answer that reliably."
    context = "\n\n".join(f"[Page {chunk.page}] {chunk.text}" for chunk in chunks)
    if llm:
        response = llm.invoke(ANSWER_PROMPTS[route].format(question=question, context=context))
        return response.content if hasattr(response, "content") else str(response)
    if demo_mode:
        lead = chunks[0].text.replace("\n", " ").strip()
        return f"Demo mode answer grounded in the report: {lead[:700]} [page {chunks[0].page}]."
    raise RuntimeError("GROQ_API_KEY is not configured.")
