from datetime import datetime, timedelta, timezone
import math
import re
from .models import CacheEntry, CacheResult


class SemanticCache:
    def __init__(self, embeddings, threshold: float, ttl_seconds: int):
        self.embeddings = embeddings
        self.threshold = threshold
        self.ttl_seconds = ttl_seconds
        self.entries: list[CacheEntry] = []

    def lookup(self, question: str) -> CacheResult:
        vector = self.embeddings.embed_query(question)
        now = datetime.now(timezone.utc)
        self.entries = [entry for entry in self.entries if entry.expires_at > now]
        best = None
        best_similarity = -1.0
        for entry in self.entries:
            if not self._numeric_constraints_match(question, entry.original_question):
                continue
            similarity = self._cosine(vector, entry.question_embedding)
            if similarity > best_similarity:
                best, best_similarity = entry, similarity
        if best and best_similarity >= self.threshold:
            return CacheResult(True, best_similarity, best.original_question, best.answer, best.metadata)
        return CacheResult(False, best_similarity if best else None, best.original_question if best else None)

    def put(self, question: str, answer: str, metadata: dict):
        now = datetime.now(timezone.utc)
        self.entries.append(CacheEntry(question, answer, self.embeddings.embed_query(question), now, now + timedelta(seconds=self.ttl_seconds), metadata))

    @staticmethod
    def _numeric_constraints_match(left: str, right: str) -> bool:
        left_numbers = set(re.findall(r"\b(?:19|20)\d{2}\b|\b\d+(?:\.\d+)?\b", left))
        right_numbers = set(re.findall(r"\b(?:19|20)\d{2}\b|\b\d+(?:\.\d+)?\b", right))
        return not left_numbers or left_numbers == right_numbers

    @staticmethod
    def _cosine(left, right):
        dot = sum(a * b for a, b in zip(left, right))
        norm = math.sqrt(sum(a * a for a in left) * sum(b * b for b in right))
        return dot / norm if norm else 0.0
