from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal

Route = Literal["direct", "thematic", "analytical"]


@dataclass
class RetrievedChunk:
    chunk_id: str
    text: str
    source: str
    page: int | None
    retrieval_score: float = 0.0
    rerank_score: float | None = None


@dataclass
class RouterDecision:
    route: Route
    reason: str
    confidence: float


@dataclass
class CacheResult:
    hit: bool
    similarity: float | None = None
    cached_question: str | None = None
    answer: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineResult:
    answer: str
    route: str
    cache_hit: bool = False
    cache_similarity: float | None = None
    cached_question: str | None = None
    expanded_queries: list[str] = field(default_factory=list)
    retrieved_chunks: list[RetrievedChunk] = field(default_factory=list)
    reranked_chunks: list[RetrievedChunk] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    latency_ms: float = 0.0
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass
class CacheEntry:
    original_question: str
    answer: str
    question_embedding: list[float]
    created_at: datetime
    expires_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)
