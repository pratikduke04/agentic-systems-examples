# Tesla Financial Report RAG Assistant

A local Streamlit RAG proof of concept over the included Tesla filing. It uses LangChain, ChromaDB, MiniLM embeddings, optional cross-encoder reranking, semantic caching, three query routes, and Groq GPT-OSS-20B generation.

## Setup

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Set `GROQ_API_KEY` in `.env` for hosted generation. For a local smoke test without a key, set `DEMO_MODE=true`; the app still loads and retrieves real passages from the included PDF, then returns a deterministic extractive response.

## Run

```powershell
streamlit run app.py
```

The first run downloads the configured embedding and reranker models and creates `chroma_db/`. Delete that directory to rebuild the index after changing chunking or the PDF. The UI exposes route, cache, expansion, retrieval, reranking, source, and timing metadata.

## Tests

```powershell
pytest -q
```
